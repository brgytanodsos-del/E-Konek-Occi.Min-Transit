# Security Setup Guide — E-Konek Occi.Min Transit

Follow these steps **before** exposing the app to real users.

---

## 1. Set required environment variables

Copy `.env.example` to `.env` and fill in every value:

```
VITE_FIREBASE_API_KEY=          # Your Firebase Web API key
VITE_FIREBASE_AUTH_DOMAIN=      # e.g. your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=       # e.g. your-project-id
VITE_FIREBASE_STORAGE_BUCKET=   # e.g. your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=

# Server-side only (not VITE_ prefixed — never exposed to browser)
SESSION_SECRET=<random 64-char string>   # Generate: openssl rand -hex 32
SETUP_SECRET=<another random secret>     # Used to protect the hash-pin endpoint
SUPERADMIN_PIN=<your chosen PIN>         # NOT stored here — hash it, store hash in Firestore
```

> **Never commit `.env` to version control.**

---

## 2. Generate hashed PINs

Start the server locally:

```bash
npm run dev
```

For each staff account, call the hash utility endpoint once:

```bash
curl -X POST http://localhost:3000/api/auth/hash-pin \
  -H "Content-Type: application/json" \
  -H "X-Setup-Secret: <your SETUP_SECRET>" \
  -d '{"pin": "YOUR_PIN_HERE"}'
```

This returns:

```json
{ "hash": "scrypt:abc123...:def456..." }
```

Copy that hash value — you'll store it in Firestore next.

---

## 3. Create admin accounts in Firestore

In the Firebase console, open **Firestore → adminAccounts** and create one document per staff member:

```json
{
  "id": "adm-port-001",
  "fullName": "Abra Port Ticketing Staff",
  "role": "port",
  "pin": "scrypt:abc123...:def456...",
  "status": "active",
  "createdAt": "<ISO timestamp>",
  "lastLogin": ""
}
```

Valid `role` values: `port`, `terminal`, `superadmin`  
The `pin` field must be the **scrypt hash** from step 2 — **never a plaintext PIN**.

---

## 4. Deploy Firestore security rules

```bash
firebase deploy --only firestore:rules
```

Verify in the Firebase console that the updated `firestore.rules` is active.

---

## 5. Remove / disable the hash-pin endpoint in production

Once all accounts are created, either:

- Unset `SETUP_SECRET` in your production environment (the endpoint returns 403 without it), or
- Delete the `/api/auth/hash-pin` route from `server/routes/authRoutes.ts`

---

## 6. GPS disclaimer

Until real GPS hardware is integrated (planned v1.1), add a visible disclaimer
to the map component so passengers know positions are simulated:

```tsx
<p className="text-xs text-amber-500 text-center mt-1">
  ⚠️ Simulated route — live GPS tracking coming in v1.1
</p>
```

---

## 7. Run the test suite

```bash
npm run lint          # TypeScript type check
npx vitest run        # Unit tests (booking + offline sync)
```

All tests should pass before deploying.

---

## Summary of files changed

| File | What changed |
|---|---|
| `server/routes/authRoutes.ts` | Removed hardcoded PINs & backdoor; scrypt hash comparison; opaque session tokens |
| `src/components/auth/PINLogin.tsx` | Removed client-side ROLE_MAP; all auth via server API |
| `src/utils/mockData.ts` | Replaced plaintext PINs with `HASH_REQUIRED` sentinel |
| `src/utils/businessLogic.ts` | Single source of truth for commission/fare; no `any` casts |
| `src/context/AppContext.tsx` | Uses unified commission; offline queue persisted to localStorage; `crypto.randomUUID()` IDs |
| `firestore.rules` | Passengers can only read own bookings; admin accounts protected; catch-all deny |
| `tests/booking.test.ts` | Real tests — commission accuracy, transaction shape, booking validation |
| `tests/offlineSync.test.ts` | Real tests — queue accumulation, persistence, dedup, clear-after-sync |
